<?php 
    include(locate_template('Module/Control/module_setting.php'));
?>