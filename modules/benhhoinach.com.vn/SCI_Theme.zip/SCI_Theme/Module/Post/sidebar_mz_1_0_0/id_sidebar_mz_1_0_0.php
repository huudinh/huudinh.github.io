<?php
    'id_sidebar_mz_1_0_0' => array(
        'key' => 'id_sidebar_mz_1_0_0',
        'name' => 'sidebar_mz_1_0_0',
        'label' => 'Sidebar 1.0.0',
        'display' => 'block',
        'sub_fields' => array(           
            array(
                'key' => 'id_sidebar_mz_1_0_0_sub3',
                'label' => 'Banner',
                'name' => 'sidebar_banner',
                'type' => 'gallery',
                'required' => 0,
                'return_format' => 'array',
                'preview_size' => 'medium',
                'insert' => 'append',
                'library' => 'all',
            ),
        ),
    ),

?>