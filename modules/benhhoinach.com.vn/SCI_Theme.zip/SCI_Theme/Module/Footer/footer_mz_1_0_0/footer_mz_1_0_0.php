<footer class="footer_mz_1_0_0">
    <div class="container">
        <div class="footer_mz_1_0_0__box">
            <p><?php echo $field["info"] ?></p>
        </div>
    </div>
</footer>