<section class="slider_mz_1_0_0">
    <div class="container">
        <a href="<?php echo $field['slide_pc'][0]['description']  ?>" target="_blank" class="slider_mz_1_0_0_item" rel="nofollow">
            <picture>
                <source media="(max-width:650px)" srcset="<?php echo $field['slide_mb'][0]['url'] ?>">
                <img src="<?php echo $field['slide_pc'][0]['url'] ?>" alt="<?php echo $field['slide_pc'][0]['title'] ?>">
            </picture>
        </a>
    </div>
</section>