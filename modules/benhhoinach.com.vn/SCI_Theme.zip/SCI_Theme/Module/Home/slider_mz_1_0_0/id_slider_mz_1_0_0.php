<?php
                                            /*Slide 1.0.0*/
                                            'id_slider_mz_1_0_0' => array(
                                                'key' => 'id_slider_mz_1_0_0',
                                                'name' => 'slider_mz_1_0_0',
                                                'label' => 'Slide 1.0.0',
                                                'display' => 'block',
                                                'sub_fields' => array(
                                                    array(
                                                        /* Tab Slider Desktop*/
                                                        'key' => 'id_slider_mz_1_0_0_tab1',
                                                        'label' => 'Slider Desktop',
                                                        'name' => '',
                                                        'type' => 'tab',
                                                    ),
                                                    array(
                                                        'key' => 'id_slider_mz_1_0_0_sub1',
                                                        'label' => 'Slide Desktop',
                                                        'name' => 'slide_pc',
                                                        'type' => 'gallery',
                                                        'instructions' => '',
                                                        'required' => 0,
                                                        'return_format' => 'array',
                                                        'preview_size' => 'medium',
                                                        'insert' => 'append',
                                                        'library' => 'all',
                                                    ),
                                                    array(
                                                        /* Tab Slider Mobile*/
                                                        'key' => 'id_slider_mz_1_0_0_tab2',
                                                        'label' => 'Slider Mobile',
                                                        'name' => '',
                                                        'type' => 'tab',
                                                    ),
                                                    array(
                                                        'key' => 'id_slider_mz_1_0_0_sub2',
                                                        'label' => 'Slide Mobile',
                                                        'name' => 'slide_mb',
                                                        'type' => 'gallery',
                                                        'instructions' => '',
                                                        'required' => 0,
                                                        'return_format' => 'array',
                                                        'preview_size' => 'medium',
                                                        'insert' => 'append',
                                                        'library' => 'all',
                                                    ),
                                                ),
                                                'min' => '',
                                                'max' => '',
                                            ),
                                            /*END Slide 1.0.0*/
?>