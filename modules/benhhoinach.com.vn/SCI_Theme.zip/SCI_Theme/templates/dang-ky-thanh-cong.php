<?php /* Template Name: Dang Ky Thanh Cong */ ?>
<?php get_header(); ?>

<main class="container">
    <?php get_template_part('Module/Category/breadcrumb_1_0_1/breadcrumb_1_0_1'); ?>
    <?php get_template_part('Module/Post/post_1_0_3/post_1_0_3'); ?>
</main>

<?php get_footer(); ?>

<script>
	setTimeout(function(){
        window.location.href = '/'  ;
    },5000);	
</script>