<?php
    // All Page
    include(locate_template('Module/assets/js/lib.min.js')); 
    include(locate_template('Module/assets/js/module.min.js')); 
    include(locate_template('Module/assets/js/custom.min.js')); 
?>