<?php 
    include(locate_template('Module/Category/sidebar_mz_1_0_0/sidebar_mz_1_0_0.php'));
?>