<?php
                            'id_footer_mz_1_0_0' => array(
                                'key' => 'id_footer_mz_1_0_0',
                                'name' => 'footer_mz_1_0_0',
                                'label' => 'Footer 1.0.0',
                                'display' => 'block',
                                'sub_fields' => array(
                                    array(
                                        'key' => 'id_footer_mz_1_0_0_sub',
                                        'label' => 'Thông Tin',
                                        'name' => 'info',
                                        'type' => 'textarea',
                                        'instructions' => '',
                                        'rows' => 2,
                                    ),
                                    array(
                                        'key' => 'id_footer_mz_1_0_0_sub_2',
                                        'label' => 'GA4',
                                        'name' => 'tracking',
                                        'type' => 'textarea',
                                        'instructions' => '',
                                        'rows' => 2,
                                    ),
                                ),
                            ),
?>