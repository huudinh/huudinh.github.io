<?php get_template_part('Module/module_footer'); ?>   
</div>
    <div id="loading"></div>
    
    <script>
        <?php include(locate_template('options/theme_js.php')); ?>
    </script>

    <?php wp_footer(); ?>
</body>

</html>